$(function () {

	setTimeout(function () {
		$('.loading').hide()

	}, 1000)

	init();
	fenxiang("安卓video", "Here is a test!", "Here is a test!", '', "https://o.cztvcloud.com/181/5843861/images/fenxiang.jpg")
	//必须在微信Weixin JSAPI的WeixinJSBridgeReady才能生效
	document.addEventListener("WeixinJSBridgeReady", function () {

	}, false);
	var playnow = false
	$('.start,.enter').click(function () {
		$('.start,.enter').hide()
		document.getElementById('video1').play()
		playnow = true
		checkVideoText(playnow)
	})
	$('.closevideo').click(function () {

		if (playnow) {
			document.getElementById('video1').pause()
			playnow = false
		} else {
			document.getElementById('video1').play()
			playnow = true
		}
 
		checkVideoText(playnow)
	})

	function checkVideoText(playnow) {
		if (playnow) {
			$('.closevideo').html('暂停视频')
		} else {
			$('.closevideo').html('开启视频')
		}
	}
})

function init() {
	if (IsPC()) {
		var height = window.innerHeight
		var width = height * 414 / 799
		console.log(width, height);
		w = height * 9 / 16 * 0.9;
		h = 666;
		// w = width;
		// h = height;
		var pcw = 750 * (w / 750); //rem
		var pch = 1334 * (w / 750); //
		$("html").css({
			'width'     : w,
			'margin'    : "0 auto",
			'marginTop' : '0',
			"height"    : "90vh",
			"background": "#fff",
			"marginTop" : "5vh", // "border"    : '1px solid grey',
			"boxShadow" : "0 0 16px 1px #00000057"
		});
		$('.main').css({
			'top': '1rem'
		})
		$("html").css({
			fontSize: w / 750 * 100 + "px"
		});
		var beishu = w / 414 * 62.5 / 48.3;
		$("html").css({
			minHeight: h
		});
	}
}

function IsPC() {
	var userAgentInfo = navigator.userAgent;
	var Agents = new Array("Android", "iPhone", "SymbianOS", "Windows Phone", "iPad", "iPod");
	var flag = true;
	for (var v = 0; v < Agents.length; v++) {
		if (userAgentInfo.indexOf(Agents[v]) > 0) {
			flag = false;
			break;
		}
	}
	return flag;
}

function GetQueryString(name) {
	var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
	var r = window.location.search.substr(1).match(reg);
	if (r != null) return unescape(r[2]);
	return null;
}

function orient() {
	if (window.orientation == 0 || window.orientation == 180) {//竖屏;//ipad、iphone竖屏；Andriod横屏
		$(".loading").hide().removeClass("hp");
		return false;
	} else if (window.orientation == 90 || window.orientation == -90) {//横屏;//ipad、iphone横屏；Andriod竖屏
		$(".loading").show().addClass("hp");
		var video = document.getElementById("video");
		video.ended();
		video.addEventListener("ended", function () {
			$("#video,.mask").hide()
		})
		$("#video").hide()
		return false;
	} else {
		$(".loading").fadeOut();
	}
}

function isAndroid() {
	var u = navigator.userAgent;
	var isAndroid = u.indexOf("Android") > -1 || u.indexOf("Adr") > -1; //android终端
	return isAndroid
}
